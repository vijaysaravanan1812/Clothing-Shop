
const AboutPage :React.FC = () =>{
  return (
    <div>AboutPage</div>
  )
}

export default AboutPage