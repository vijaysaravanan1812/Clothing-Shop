import React from 'react';
import ProductSlide from '../ProductSlide/ProductSlide';

const HomePage: React.FC = () => {
  return (
      <ProductSlide />
  );
}

export default HomePage;
