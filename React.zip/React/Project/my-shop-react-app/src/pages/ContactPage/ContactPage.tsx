
const ContactPage :React.FC = () => {
  return (
    <div>ContactPage</div>
  )
}

export default ContactPage