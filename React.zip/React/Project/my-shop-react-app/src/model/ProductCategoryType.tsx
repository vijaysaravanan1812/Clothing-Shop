interface Category {
    id: string;
    name: string;
}