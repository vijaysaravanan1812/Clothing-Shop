

export const URL = {
     GET_PRODUCT_CATEGORY : "http://localhost:3000/categories",
     GET_PRODUCT_URL :  "http://localhost:3000/products",
}
